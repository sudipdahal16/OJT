<?php

if ( ! is_active_sidebar( 'footer-instagram' ) ) {
	return;
}
?>

<div class="footer-instagram">
	<?php dynamic_sidebar( 'footer-instagram' ); ?>
</div>
